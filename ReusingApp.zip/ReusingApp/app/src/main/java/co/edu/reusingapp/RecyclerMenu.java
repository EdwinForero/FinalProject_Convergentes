package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RecyclerMenu extends AppCompatActivity {
    public static final String TXT_EMAIL = "mail";
    TextView txtReciclador;
    DatabaseReference mReference;
    ImageView imgEx, imgCheck, imgOrd, imgUpd;
    String mail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_menu);
        imgCheck = findViewById(R.id.historyReview);
        txtReciclador = findViewById(R.id.eUser);
        mReference = FirebaseDatabase.getInstance().getReference();
        imgEx = (ImageView) findViewById(R.id.btnExitUser);
        imgOrd = (ImageView) findViewById(R.id.imgUserOrd);
        imgUpd = (ImageView) findViewById(R.id.imgUpdateUser);
        Intent intent = getIntent();
        mail = intent.getStringExtra(mail);


        imgCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = getIntent();
                mail = n.getStringExtra(TXT_EMAIL);
                Intent intent = new Intent(getApplicationContext(), History.class);
                intent.putExtra("mail",mail);
                startActivity(intent);
                finish();
            }
        });

        imgUpd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = getIntent();
                mail = n.getStringExtra(TXT_EMAIL);
                Intent intent = new Intent(getApplicationContext(), UpdateProfileRecycler.class);
                intent.putExtra("mail",mail);
                startActivity(intent);
                finish();
            }
        });
        imgOrd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = getIntent();
                mail = n.getStringExtra(TXT_EMAIL);
                Intent intent = new Intent(getApplicationContext(),SeeOrderRecycler.class);
                intent.putExtra("mail",mail);
                startActivity(intent);
                finish();
            }
        });

        mReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mReference.child("Users").child(snap.getKey()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User uRec = snap.getValue(User.class);
                            Intent intent = getIntent();
                            mail = intent.getStringExtra(TXT_EMAIL);
                            if (uRec.getEmail().equals(mail)) {
                                txtReciclador.setText(" Welcome " + uRec.getName() + "!");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void exitBtn(View view) {
        Intent intent = new Intent(getApplicationContext(), ReusingApp.class);
        startActivity(intent);
        finish();
    }


}