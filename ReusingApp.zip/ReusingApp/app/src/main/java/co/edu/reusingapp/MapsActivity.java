package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationListenerCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.ILocationSourceDelegate;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import co.edu.reusingapp.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback{

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private LocationManager locationManager;
    private Location currenLocation;
    private Polyline polyline;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng bogota = new LatLng(4.631946, -74.065675);
        LatLng subachoque = new LatLng(4.877293, -74.186019);
        mMap.addMarker(new MarkerOptions().position(subachoque).title("Marker in Subachoque").icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_shop)));
        mMap.addMarker(new MarkerOptions().position(bogota).title("Marker in Bogota").icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_bike)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(subachoque));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(subachoque)
                .zoom(13)
                .bearing(90)
                .tilt(45)
                .build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        polyline = googleMap.addPolyline(new PolylineOptions()
        .clickable(true)
        .add(
                new LatLng(4.631368, -74.065232),
                new LatLng(4.632523, -74.067730),
                new LatLng(4.653012, -74.063932),
                new LatLng(4.665892, -74.060947),
                new LatLng(4.674959,-74.068718),
                new LatLng(4.685000, -74.079717),
                new LatLng(4.693912, -74.086920),
                new LatLng(4.703403, -74.101432),
                new LatLng(4.707336, -74.109309),
                new LatLng(4.726427, -74.124896),
                new LatLng(4.727410, -74.125121),
                new LatLng(4.728377, -74.126399),
                new LatLng(4.730578, -74.128677),
                new LatLng(4.797678, -74.207811),
                new LatLng(4.807303, -74.212122),
                new LatLng(4.815297, -74.223071),
                new LatLng(4.819010, -74.222354),
                new LatLng(4.837180, -74.212618),
                new LatLng(4.839197, -74.210138),
                new LatLng(4.842677, -74.208347),
                new LatLng(4.846356, -74.204211),
                new LatLng(4.856161, -74.193285),
                new LatLng(4.859256, -74.192060),
                new LatLng(4.862842, -74.192002),
                new LatLng(4.863979, -74.190890),
                new LatLng(4.877406, -74.185981)

        )
        );

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(false);

        LocationManager locationManager = (LocationManager) MapsActivity.this.getSystemService(Context.LOCATION_SERVICE);
        LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                LatLng myLocation = new LatLng(location.getLatitude(),location.getLongitude());
                mMap.addMarker(new MarkerOptions().position(myLocation).title("Recycler").icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_bike)));
            }
        };
        int permiso = ContextCompat.checkSelfPermission(MapsActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,0,0,locationListener);
    }
}