package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

public class PublishOrder extends AppCompatActivity {
    EditText txtHeight, txtWeight, txtEmail, txtAdress;
    Spinner typeM, typeZ;
    Button btnPublish;
    DatabaseReference mReference;
    ArrayList<Pedidos>  pedidos = new ArrayList<Pedidos>();
    final static String TXT_EMAIL = "mail";
    private String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_order);

        txtHeight = findViewById(R.id.height_txt);
        txtWeight = findViewById(R.id.weightTxt);
        typeM = findViewById(R.id.spinnerTypeMaterial);
        typeZ = findViewById(R.id.sizeMaterialSpinner);
        txtEmail = findViewById(R.id.emailPublish);
        txtAdress = findViewById(R.id.adressPublish);
        btnPublish = findViewById(R.id.publish);
        mReference = FirebaseDatabase.getInstance().getReference();

        Intent intent = getIntent();
        email = intent.getStringExtra(TXT_EMAIL);

        mReference.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snap: snapshot.getChildren()){
                    mReference.child("Users").child(snap.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User user = snap.getValue(User.class);
                            if(user.getEmail().equals(email)){
                                txtEmail.setText(user.getEmail());
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String height = txtHeight.getText().toString();
                String weight = txtWeight.getText().toString();
                String typeMat = typeM.getSelectedItem().toString();
                String typeZa = typeZ.getSelectedItem().toString();
                String eMail = txtEmail.getText().toString();
                String address = txtAdress.getText().toString();
                String state = "Publicated";
                String asigned = "Not asigned";

                if(height.isEmpty() || weight.isEmpty() || typeMat.isEmpty() || typeZa.isEmpty() || email.isEmpty() || address.isEmpty()){
                    Toast.makeText(PublishOrder.this, "All fields must be complete", Toast.LENGTH_SHORT).show();
                }else{
                    Pedidos pedidos = new Pedidos();
                    pedidos.setGuideNumber(UUID.randomUUID().toString());
                    pedidos.setAddress(address);
                    pedidos.setEmail(eMail);
                    pedidos.setHeight(height);
                    pedidos.setWeight(weight);
                    pedidos.setSize(typeZa);
                    pedidos.setMaterial(typeMat);
                    pedidos.setState(state);
                    pedidos.setAsigned(asigned);
                    mReference.child("Orders").child(pedidos.getGuideNumber()).setValue(pedidos).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(PublishOrder.this, "Posted Order", Toast.LENGTH_SHORT).show();
                                Intent n = new Intent(getApplicationContext(),MainMenuUser.class);
                                n.putExtra("mail", email);
                                startActivity(n);
                                finish();
                            } else {
                                Toast.makeText(PublishOrder.this, "We cant post your order, Check again", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }


            }
        });

    }



    @Override
    public void onBackPressed() {
        Intent n = new Intent(getApplicationContext(),MainMenuUser.class);
        n.putExtra("mail",email);
        startActivity(n);
        finish();
        super.onBackPressed();
    }
}