package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SeeOrderUser extends AppCompatActivity {
    DatabaseReference mReference;
    ArrayList<Pedidos> arrPedidos = new ArrayList<Pedidos>();
    final static String TXT_EMAIL = "mail";
    ListView lViewUser;
    Pedidos pedidosSelected;
    ArrayAdapter<Pedidos> arrAdapter;
    String mail;

    String name = "";
    String address = "";
    String email = "";
    String guideNumber = "";
    String height = "";
    String size = "";
    String material = "";
    String weight = "";
    String state = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_order_user);
        lViewUser = findViewById(R.id.ListViewRecycler);
        mReference = FirebaseDatabase.getInstance().getReference();
        arrAdapter = new ArrayAdapter<Pedidos>(SeeOrderUser.this, android.R.layout.simple_list_item_1, arrPedidos);
        lViewUser.setAdapter(arrAdapter);
        Intent intent = getIntent();
        mail = intent.getStringExtra(TXT_EMAIL);

        mReference.child("Orders").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mReference.child("Orders").child(snap.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Pedidos value = snap.getValue(Pedidos.class);
                            if (value.getEmail().equals(mail)) {
                                arrPedidos.add(value);
                                arrAdapter.notifyDataSetChanged();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        lViewUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                pedidosSelected = (Pedidos) adapterView.getItemAtPosition(i);
                Toast.makeText(SeeOrderUser.this, "You have selected" + pedidosSelected + "\n", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete:
                    if(pedidosSelected != null){
                        Pedidos p1 = new Pedidos();
                        p1.setAddress(address);
                        p1.setEmail(email);
                        p1.setHeight(height);
                        p1.setSize(size);
                        p1.setMaterial(material);
                        p1.setWeight(weight);
                        p1.setState("On the way");
                        p1.setAsigned(name);
                        p1.setGuideNumber(pedidosSelected.getGuideNumber());
                        mReference.child("Finalized").child(p1.getGuideNumber()).setValue(p1);
                        mReference.child("Orders").child(p1.getGuideNumber()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Intent n = new Intent(getApplicationContext(), SeeOrderUser.class);
                                    n.putExtra("mail", mail);
                                    startActivity(n);
                                    finish();
                                }
                            }
                        });
                    }else{
                        Toast.makeText(this, "You have to select an order", Toast.LENGTH_SHORT).show();
                    }

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        Intent n = new Intent(getApplicationContext(), MainMenuUser.class);
        n.putExtra("mail", mail);
        startActivity(n);
        finish();
        super.onBackPressed();
    }
}