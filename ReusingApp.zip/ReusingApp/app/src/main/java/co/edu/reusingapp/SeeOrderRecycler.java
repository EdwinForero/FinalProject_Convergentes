package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SeeOrderRecycler extends AppCompatActivity {
    DatabaseReference mReference;
    ArrayList<Pedidos> arrPedidos = new ArrayList<Pedidos>();
    final static String TXT_EMAIL = "mail";
    ListView lViewRecycler;
    Pedidos pedidosSelected;
    ArrayAdapter<Pedidos> arrAdapter;
    String mail;
    String name = "";

    String address = "";
    String email = "";
    String guideNumber = "";
    String height = "";
    String size = "";
    String material = "";
    String weight = "";
    String state = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_order_recycler);

        lViewRecycler = findViewById(R.id.ListViewRecycler);
        mReference = FirebaseDatabase.getInstance().getReference();
        arrAdapter = new ArrayAdapter<Pedidos>(SeeOrderRecycler.this, android.R.layout.simple_list_item_1, arrPedidos);
        lViewRecycler.setAdapter(arrAdapter);
        Intent intent = getIntent();
        mail = intent.getStringExtra(TXT_EMAIL);

        mReference.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot sn : snapshot.getChildren()) {
                    mReference.child("Users").child(sn.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User u = sn.getValue(User.class);
                            if (u.getEmail().equals(mail)) {
                                name = u.getName();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        mReference.child("Orders").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mReference.child("Orders").child(snap.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Pedidos value = snap.getValue(Pedidos.class);
                            arrPedidos.add(value);
                            arrAdapter.notifyDataSetChanged();
                            material = value.getMaterial();
                            size = value.getSize();
                            weight = value.getWeight();
                            height = value.getHeight();
                            address = value.getAddress();
                            email = value.getEmail();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }

        });

        lViewRecycler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                pedidosSelected = (Pedidos) adapterView.getItemAtPosition(i);
                Toast.makeText(SeeOrderRecycler.this, "You have selected" + pedidosSelected + "\n", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.apply:
                if (pedidosSelected != null) {
                    Pedidos p = new Pedidos();
                    p.setAddress(address);
                    p.setEmail(email);
                    p.setHeight(height);
                    p.setSize(size);
                    p.setMaterial(material);
                    p.setWeight(weight);
                    p.setState("Asigned");
                    p.setAsigned(name);
                    p.setGuideNumber(pedidosSelected.getGuideNumber());
                    if (pedidosSelected.getState().equals("Asigned")) {
                        Toast.makeText(this, "You already have this order asigned to you", Toast.LENGTH_SHORT).show();
                    } else {
                        mReference.child("Orders").child(p.getGuideNumber()).setValue(p).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(SeeOrderRecycler.this, "You are now asigned to this order", Toast.LENGTH_SHORT).show();
                                    Intent n = new Intent(getApplicationContext(), SeeOrderRecycler.class);
                                    n.putExtra("mail", mail);
                                    startActivity(n);
                                    finish();
                                }
                            }
                        });
                    }

                }
                break;
            case R.id.entregado:
                if (pedidosSelected != null) {
                    Pedidos p = new Pedidos();
                    p.setAddress(address);
                    p.setEmail(email);
                    p.setHeight(height);
                    p.setSize(size);
                    p.setMaterial(material);
                    p.setWeight(weight);
                    p.setState("Delivered");
                    p.setAsigned(name);
                    p.setGuideNumber(pedidosSelected.getGuideNumber());
                    mReference.child("Orders").child(p.getGuideNumber()).removeValue();
                    mReference.child("Finalized").child(p.getGuideNumber()).setValue(p).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(SeeOrderRecycler.this, "You just deliver this order", Toast.LENGTH_SHORT).show();
                                    Intent n = new Intent(getApplicationContext(), SeeOrderRecycler.class);
                                    n.putExtra("mail", mail);
                                    startActivity(n);
                                    finish();
                                }
                            }
                        });
                    }
                break;

            case R.id.onMyway:
                if (pedidosSelected != null) {
                    Pedidos p = new Pedidos();
                    p.setAddress(address);
                    p.setEmail(email);
                    p.setHeight(height);
                    p.setSize(size);
                    p.setMaterial(material);
                    p.setWeight(weight);
                    p.setState("On the way");
                    p.setAsigned(name);
                    p.setGuideNumber(pedidosSelected.getGuideNumber());
                    if (pedidosSelected.getState().equals("On the way")) {
                        Toast.makeText(this, "The order is on the way", Toast.LENGTH_SHORT).show();
                    } else {
                        mReference.child("Orders").child(p.getGuideNumber()).setValue(p).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(SeeOrderRecycler.this, "The order is on its way", Toast.LENGTH_SHORT).show();
                                    Intent n = new Intent(getApplicationContext(), SeeOrderRecycler.class);
                                    n.putExtra("mail", mail);
                                    startActivity(n);
                                    finish();
                                }
                            }
                        });
                    }


                }

                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_recycler, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        Intent n = new Intent(getApplicationContext(), RecyclerMenu.class);
        n.putExtra("mail", mail);
        startActivity(n);
        finish();
        super.onBackPressed();
    }
}