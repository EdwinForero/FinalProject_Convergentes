package co.edu.reusingapp;

public class Pedidos {

    private String address;
    private String email;
    private String guideNumber;
    private String height;
    private String size;
    private String material;
    private String weight;
    private String state;
    private String asigned;

    public String getAsigned() {
        return asigned;
    }

    public void setAsigned(String asigned) {
        this.asigned = asigned;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGuideNumber() {
        return guideNumber;
    }

    public void setGuideNumber(String guideNumber) {
        this.guideNumber = guideNumber;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Pedido: "+ "\n" +
                "Guide Number:" + " " + guideNumber + "\n" +
                "Material" + " " + material + "\n"+
                "Email: " + " " + email + "\n" +
                "State: " + " " + state + "\n" +
                "Asigned" + " " + asigned;
    }
}
