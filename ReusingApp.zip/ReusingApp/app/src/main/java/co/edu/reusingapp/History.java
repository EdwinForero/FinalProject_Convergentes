package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class History extends AppCompatActivity {
    DatabaseReference mReference;
    ArrayList<Finalized> arrPedidos = new ArrayList<Finalized>();
    final static String TXT_EMAIL = "mail";
    ListView lViewUser;
    Pedidos pedidosSelected;
    ArrayAdapter<Finalized> arrAdapter;
    String mail;
    String asigned;
    String type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        lViewUser = findViewById(R.id.historyView);
        mReference = FirebaseDatabase.getInstance().getReference();
        arrAdapter = new ArrayAdapter<Finalized>(History.this, android.R.layout.simple_list_item_1, arrPedidos);
        lViewUser.setAdapter(arrAdapter);
        Intent intent = getIntent();
        mail = intent.getStringExtra(TXT_EMAIL);

        mReference.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snp : snapshot.getChildren()) {
                    mReference.child("Users").child(snp.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User user = snp.getValue(User.class);
                            if (user.getEmail().equals(mail)) {
                                asigned = user.getName();
                                type =user.getUsertype();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        mReference.child("Finalized").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mReference.child("Finalized").child(snap.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            Finalized finalized = snap.getValue(Finalized.class);
                            if (finalized.getEmail().equals(mail) || finalized.getAsigned().equals(asigned)) {
                                arrPedidos.add(finalized);
                                arrAdapter.notifyDataSetChanged();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    public void onBackPressed() {
        mReference.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snp1 : snapshot.getChildren()) {
                    mReference.child("Users").child(snp1.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User us = snp1.getValue(User.class);
                            Intent intent;
                            if(us.getUsertype().equals(type)) {
                                intent = new Intent(getApplicationContext(), MainMenuUser.class);
                            } else {
                                intent = new Intent(getApplicationContext(), RecyclerMenu.class);

                            }
                            intent.putExtra("mail", mail);
                            startActivity(intent);
                            finish();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        super.onBackPressed();
    }
}