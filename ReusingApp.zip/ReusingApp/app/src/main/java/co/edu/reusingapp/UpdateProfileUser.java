package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class UpdateProfileUser extends AppCompatActivity {
    EditText txtName, txtPhone, txtAdress, txtPass, txtConfirm;
    Button btnUpdateUser;
    DatabaseReference mDataReference;
    private static String TXT_MAIL = "mail";
    private String mail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile_user);
        txtName = findViewById(R.id.updNameUser);
        txtPhone = findViewById(R.id.updPhoneUser);
        txtAdress = findViewById(R.id.updAdressUser);
        txtPass = findViewById(R.id.updPassUser);
        txtConfirm = findViewById(R.id.updConfirmPassUser);
        btnUpdateUser = findViewById(R.id.updInfoUser);
        mDataReference = FirebaseDatabase.getInstance().getReference();

        Intent intent = getIntent();
        mail = intent.getStringExtra(TXT_MAIL);


        mDataReference.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mDataReference.child("Users").child(snap.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User rec = snap.getValue(User.class);
                            if (rec.getEmail().equals(mail)) {
                                txtName.setText(rec.getName().toString());
                                txtPhone.setText(rec.getPhone().toString());
                                txtAdress.setText(rec.getAdress().toString());
                                txtPass.setText(rec.getPassword().toString());

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        btnUpdateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDataReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot snap1 : snapshot.getChildren()) {
                            mDataReference.child("Users").child(snap1.getKey()).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    User recy = snap1.getValue(User.class);
                                    if (recy.getEmail().equals(mail)) {
                                        if (txtPass.getText().toString().equals(txtConfirm.getText().toString())) {
                                            Map<String, Object> updRec = new HashMap<>();
                                            updRec.put("name", txtName.getText().toString());
                                            updRec.put("phone", txtPhone.getText().toString());
                                            updRec.put("adress", txtAdress.getText().toString());

                                            mDataReference.child("Users").child(snap1.getKey()).updateChildren(updRec);
                                            Intent n = new Intent(getApplicationContext(), MainMenuUser.class);
                                            n.putExtra("mail", mail);
                                            startActivity(n);
                                            finish();
                                        } else {
                                            Toast.makeText(UpdateProfileUser.this, "You have to confirm password to update your info", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });


    }
    @Override
    public void onBackPressed() {
        Intent n = new Intent(getApplicationContext(), MainMenuUser.class);
        n.putExtra("mail", mail);
        startActivity(n);
        finish();
        super.onBackPressed();
    }
}