package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RegisterUser extends AppCompatActivity {
    EditText txtName,txtEmail,txtPhone,txtAdress,txtPassword,txtConfirmPassword;
    Button btnRegistrar;
    Spinner spinner;
    //Variables
    private String name="";
    private String email="";
    private String phone="";
    private String adress="";
    private String pass="";
    private String confirmPass="";
    private String userType="";
    ArrayList<User> users = new ArrayList<User>();
    FirebaseAuth mAuth;
    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        txtName = (EditText) findViewById(R.id.nombreR);
        txtEmail = (EditText) findViewById(R.id.emailR);
        txtPhone = (EditText) findViewById(R.id.phoneR);
        txtAdress = (EditText) findViewById(R.id.direccionR);
        txtPassword = (EditText) findViewById(R.id.passwordR);
        txtConfirmPassword = (EditText) findViewById(R.id.confirmarpass);
        spinner = (Spinner) findViewById(R.id.spinner_UoR);
        userType = spinner.getSelectedItem().toString();
        btnRegistrar = (Button) findViewById(R.id.btnRegistrarse);

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabase = FirebaseDatabase.getInstance().getReference();
                mAuth = FirebaseAuth.getInstance();
                name = txtName.getText().toString();
                email = txtEmail.getText().toString();
                phone = txtPhone.getText().toString();
                adress = txtAdress.getText().toString();
                pass = txtPassword.getText().toString();
                userType = spinner.getSelectedItem().toString();
                confirmPass = txtConfirmPassword.getText().toString();


                if(!name.isEmpty() && !email.isEmpty() && !phone.isEmpty() && !adress.isEmpty() && !pass.isEmpty() && !confirmPass.isEmpty()){
                    if(pass.length()>=6){
                       if(pass.equals(confirmPass)){
                           registerUser();
                       }else{
                           Toast.makeText(RegisterUser.this, "Password does not match", Toast.LENGTH_SHORT).show();
                       }
                    }else{
                        Toast.makeText(RegisterUser.this, "Password needs more than 6 characters", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(RegisterUser.this, "Please complete all the fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(),ReusingApp.class));
        finish();
    }

    private void registerUser(){
        mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    User user = new User();
                    user.setUsertype(userType);
                    user.setName(name);
                    user.setEmail(email);
                    user.setAdress(adress);
                    user.setPhone(phone);
                    user.setPassword(pass);
                    user.setIdUser(UUID.randomUUID().toString());
                    mDatabase.child("Users").child(user.getIdUser()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task2) {
                            if(task2.isSuccessful()){
                                startActivity(new Intent(RegisterUser.this,ReusingApp.class));
                                finish();
                            }else{
                                Toast.makeText(RegisterUser.this, "Data was not save", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else{
                    Toast.makeText(RegisterUser.this, "could not register", Toast.LENGTH_SHORT).show();
                }

            }
        });


        }
    }



