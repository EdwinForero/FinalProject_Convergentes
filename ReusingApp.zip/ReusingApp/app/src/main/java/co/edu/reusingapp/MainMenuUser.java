package co.edu.reusingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainMenuUser extends AppCompatActivity {
    ImageView imgSeeOrder, imgPublish, imgUpdateUser, imgExit,imgMap;
    DatabaseReference mReference;
    final static String TXT_EMAIL = "mail";
    String mail;
    TextView txtUser,txtHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu_user);
        txtHistory = findViewById(R.id.historyText);
        txtUser = findViewById(R.id.eUser);
        imgSeeOrder = findViewById(R.id.imgUserOrd);
        imgPublish = findViewById(R.id.publishPro);
        imgUpdateUser = findViewById(R.id.imgUpdateUser);
        imgExit = findViewById(R.id.btnExitUser);
        imgMap = findViewById(R.id.mapView);
        mReference = FirebaseDatabase.getInstance().getReference();


        txtHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                mail = intent.getStringExtra(TXT_EMAIL);
                Intent n = new Intent(getApplicationContext(), History.class);
                n.putExtra("mail", mail);
                startActivity(n);
                finish();
            }
        });

        imgMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                mail = intent.getStringExtra(TXT_EMAIL);
                Intent n = new Intent(getApplicationContext(), MapsActivity.class);
                n.putExtra("mail", mail);
                startActivity(n);
                finish();

            }
        });

        imgSeeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                mail = intent.getStringExtra(TXT_EMAIL);
                Intent n = new Intent(getApplicationContext(), SeeOrderUser.class);
                n.putExtra("mail", mail);
                startActivity(n);
                finish();
            }
        });
        imgPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = getIntent();
                mail = n.getStringExtra(TXT_EMAIL);
                Intent intent = new Intent(getApplicationContext(), PublishOrder.class);
                intent.putExtra("mail",mail);
                startActivity(intent);
                finish();
            }
        });

        imgExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ReusingApp.class));
                finish();
            }
        });
        imgUpdateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = getIntent();
                mail = n.getStringExtra(TXT_EMAIL);
                Intent intent = new Intent(getApplicationContext(), UpdateProfileUser.class);
                intent.putExtra("mail",mail);
                startActivity(intent);
                finish();
            }
        });


        mReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    mReference.child("Users").child(snap.getKey()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User uRec = snap.getValue(User.class);
                            Intent intent = getIntent();
                            String mail = intent.getStringExtra(TXT_EMAIL);
                            if (uRec.getEmail().equals(mail)) {
                                txtUser.setText(" Welcome " + uRec.getName() + "!");
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}




