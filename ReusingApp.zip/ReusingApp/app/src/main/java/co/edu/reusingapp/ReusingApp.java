package co.edu.reusingapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReusingApp extends AppCompatActivity {
    TextView txtSign, txtForgot;
    EditText eEmail, ePass;
    FirebaseAuth mAuth;
    DatabaseReference mDataRef;
    Intent n;
    private String uRec = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reusing_main);
        txtForgot = findViewById(R.id.View_ForgotPass);
        txtSign = findViewById(R.id.view_SignUp);
        eEmail = findViewById(R.id.email_view);
        ePass = findViewById(R.id.password_textView);
        mAuth = FirebaseAuth.getInstance();
        mDataRef = FirebaseDatabase.getInstance().getReference();

        txtForgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ForgotPassword.class));
                finish();
            }
        });
        txtSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sign = new Intent(getApplicationContext(), RegisterUser.class);
                startActivity(sign);
                finish();
            }
        });
    }

    public void login(View view) {
        if ((eEmail.getText().toString().isEmpty() || ePass.getText().toString().isEmpty())) {
            Toast.makeText(this, "Check your user and password", Toast.LENGTH_SHORT).show();
        } else {
            mAuth.signInWithEmailAndPassword(eEmail.getText().toString(), ePass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        mDataRef.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot snap : snapshot.getChildren()) {
                                    mDataRef.child("Users").child(snap.getKey()).addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            User uR = snap.getValue(User.class);
                                            if (uR.getEmail().equals(eEmail.getText().toString())) {
                                                Toast.makeText(ReusingApp.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                                if (uR.getUsertype().equals("Recycler")) {
                                                    n = new Intent(getApplicationContext(), RecyclerMenu.class);
                                                    n.putExtra("mail", eEmail.getText().toString());
                                                    startActivity(n);
                                                    finish();
                                                } else {
                                                    User userM = snap.getValue(User.class);
                                                    n = new Intent(getApplicationContext(), MainMenuUser.class);
                                                    n.putExtra("mail", eEmail.getText().toString());
                                                    startActivity(n);
                                                    finish();
                                                }
                                            }
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                        }
                                    });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                        finish();

                    } else {
                        Toast.makeText(ReusingApp.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }


}